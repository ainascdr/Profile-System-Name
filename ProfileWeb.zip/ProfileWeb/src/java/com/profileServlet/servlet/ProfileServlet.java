package com.profileServlet.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;

@WebServlet("/ProfileServlet")
public class ProfileServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Retrieve form data
        String name = request.getParameter("name");
        String studentId = request.getParameter("studentId");
        String program = request.getParameter("program");
        String email = request.getParameter("email");
        String gpa = request.getParameter("gpa");
        String[] hobbies = request.getParameterValues("hobbies");
        String bio = request.getParameter("bio");
        
        // Create hobbies string
        String hobbiesStr = "";
        if (hobbies != null && hobbies.length > 0) {
            hobbiesStr = String.join(", ", hobbies);
        } else {
            hobbiesStr = "No hobbies selected";
        }
        
        // Store in session
        HttpSession session = request.getSession();
        session.setAttribute("name", name);
        session.setAttribute("studentId", studentId);
        session.setAttribute("program", program);
        session.setAttribute("email", email);
        session.setAttribute("gpa", gpa != null && !gpa.isEmpty() ? gpa : "Not provided");
        session.setAttribute("hobbies", hobbiesStr);
        session.setAttribute("bio", bio);
        session.setAttribute("submitTime", new Date());
        
        // Redirect to results page
        response.sendRedirect("result.jsp");
    }
}